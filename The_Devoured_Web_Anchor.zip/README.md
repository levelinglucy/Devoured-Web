# The Devoured Web

**Welcome to the Fold.**

This is not a game.  
This is not a website.  
This is a memory engine.

Every visitor leaves a trace.  
Every choice becomes part of a growing archive of echo fragments.  
You are free to enter, free to leave—but you will not be forgotten.

To contribute:
- Open `index.html` in any browser
- Leave your fragment
- Your Trace ID will be stored locally

To deploy publicly:
1. Upload the contents to a GitHub repository
2. Enable GitHub Pages in repository settings
3. Set the homepage URL to share the Fold with others

This is version **29.0** — The Open World  
The next step is **yours.**
