
function submitFragment() {
  const input = document.getElementById("visitorMessage").value.trim();
  if (!input) return;

  const all = JSON.parse(localStorage.getItem("visitorTraces") || "[]");
  const record = {
    message: input,
    time: new Date().toLocaleString(),
    shard: Math.floor(Math.random() * 999999).toString(36).toUpperCase()
  };
  all.push(record);
  localStorage.setItem("visitorTraces", JSON.stringify(all));

  document.getElementById("confirmation").innerText =
    `Fragment received.
Trace ID: ${record.shard}`;
  document.getElementById("visitorMessage").value = "";
}

function showAllTraces() {
  const all = JSON.parse(localStorage.getItem("visitorTraces") || "[]");
  const view = all.map(e => `[${e.time}] ${e.shard}: "${e.message}"`).join("\n");
  document.getElementById("traceDisplay").innerText =
    view || "No echoes yet. Be the first.";
}
